create FUNCTION get_seq
	RETURN NUMBER 
IS
BEGIN
	RETURN memberphoto_seq.nextval;
END;
/

